public class CoreService {
    public void processData() {
        System.out.println("Basic Data Processing");
        // Initialization code
    }

    public void commonUtil() {
        System.out.println("Common Util v1.0");
    }
}
